--- Touhou 17 WBaWC practice patch by Priw8, v1.0 ---

# Usage
Simply put the included executable in the same folder as the base game and then run it instead of the regular one.

# Features
- Warp to any stage section, nonspell or spell in the game
- For Saki's final, it's also possible to warp to any phase. This may be also implemented for Keiki's final in the future, but in that case it's more complicated to do properly
- Set initial bombs/lives
- Invincibility cheat (muteki)
- Set initial tokens (goast)

# Known bugs
- The section number is sometimes not properly reset, allowing selecting invalid sections. Invalid sections don't crash the game, they simply do nothing. This will be fixed in a future version.
- The "extra beasts appeared" bug can occur in practice. I blame ZUN for this, maybe this will be fixed in the future, maybe not.
* In case of encountering a bug that's not on the list, report it to Priw8#9873

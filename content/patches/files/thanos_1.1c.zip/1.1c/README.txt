---- Thanos patches by Priw8, release 1.1c ----
Supported games: 10, 11*, 12, 12.5, 13, 14, 14.3, 15, 16, 16.5.
Report crashes to Priw8#9873
In order to apply the patch correctly, you have to follow both sets of instructions below.

* th11 has a bug with enemies that stay offscreen and can be only killed with bombs. th10 had that too in 1.0a but I managed to fix it

---- WHAT THE HECK IS THIS ----
This patch makes the game randomly ignore certain ECL instructions. In other words, it corrupts what the enemies do. Wacky shenanigans are bound to happen!

---- APPLYING THE PATCH - .DAT FILE ----
0. This is only for th13, th14, th15 and th16. Other games don't have any .dat patches at the moment.
1. Move thxx.dat file from game's folder to this folder. Make sure to have a backup of it somewhere, since following steps will overwrite it!
2. Open the command prompt in this folder (you can do so by typing "cmd" in the current folder path in file explorer, or by opening cmd normally and navigating to this folder in it)
3. Type "patch n" in the command prompt, where "n" is the game number.
4. The file should be patched now. You can move it back to game's folder.

---- APPLYING THE PATCH - EXECUTABLE ----
0. You need to use Cheat Engine to apply the patch to the game. If you don't have it, install it.
1. Run Cheat Engine andthe game you want to patch, and open the game's process in Cheat Engine.
2. Open corresponding text file from this folder (LoLK = 15.txt). In case of Double Spoiler, there is also a th12.5respawn.txt, which contains a cheat that makes the player respawn after getting hit.
3. In Cheat Engine, click "memory view", and a window will open. In this window, select "auto assemble" from "tools" on the upper bar, or press Ctrl+A
4. The auto assemble window will open. Paste contents of the .txt file opened earlier into it, click the "Execute" button and confirm.
5. The patch has now been applied. Keep in mind that this is only temporary, and you have to repeat this every time you restart the game.

---- NOTES ----
- Replays don't work in VD, ISC and DS patches (desync).
- the SA patch has an issue with offscreen enemies, because the player shots despawn before they can hit. Because of that, the only way of killing these enemies is by using bombs. I plan to fix that in a later version, but for now I don't know how.
- MoF/SA/UFO patches might be a bit unstable (if anything crashes, tell me)
- Mamizou is unstable on some spells, this will be fixed in a future version
- LoLK extra stage can softlock at the end, use a practice patch to skip to the boss if that happens to you (I have to say, softlocking an autoscroller is a pretty good meme)
- HSiFS has 25% chance to softlock at the end of Mai and Satono fight, you can remove that risk by uncommenting the code for making Enm_call unskippable in 16.txt. The reason why this is not the default is that the fight becomes hilariously broken when Enm_call can be skipped, and I think it's worth the 25% risk lmao

---- ROLES OF THE ECL FILES ----
- th13/st05.ecl - remove potential softlock at the end of stage 5
- th13/st05mbs.ecl - remove potential infinite loop in Tojiko's midboss spell
- th14/everything - remove potential infinite loops in Yatsuhashi's patterns (yes, st4 midboss/st4 boss/ex midboss could all do that, Yatsuhashi is not a fan of this patch)
- th15/st06bs.ecl - remove potential game crash on Lillies (actually this just makes it super unlikely to happen, chance for that is around 1/2^500 aka not ever happening tier) (yes I just put the instructions that must not be skipped in a loop that executes 500 times lmao)
- th15/st07.ecl - remove potential softlock at the end of the extra stage
- th16/everything - fix extra stage crashes caused by killing enemies spawned during spellcards (not exactly sure what's the cause of them, the workaround is lazy)
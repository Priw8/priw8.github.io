-- Wacky Necrodancer mods by Priw8#9873, revision 1 --
-- More information: http://priw8.github.io/#s=patches/necrodancer --

APPLYING THE MODS:
0. You need to use Cheat Engine to apply the patch to the game. If you don't have it, install it.
1. Run Cheat Engine and Necrodancer, open Necrodancer's process in Cheat Engine.
2. Load the provited .ct (cheat table?) file (file -> load or Ctrl+O).
3. Use the checkboxes in the Cheat Engine's window to activate/disable mods.

Enabling any of the mods disables submitting to leaderboards until the game is fully restarted.
Restarting the game also resets any changes that the mods have made.



Note: Coda with Marv and Tempo's curse is probably impossible

